class TextEditor {
    constructor() {
        this.text = '';
    }

    init() {
        const editorElement = document.createElement('textarea');
        editorElement.addEventListener('input', (event) => {
            this.setText(event.target.value);
        });
        document.body.appendChild(editorElement);
    }

    getText() {
        return this.text;
    }

    setText(newText) {
        this.text = newText;
    }
}

export default TextEditor;