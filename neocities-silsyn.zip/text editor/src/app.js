document.addEventListener("DOMContentLoaded", () => {
  const textEditor = document.getElementById("text-editor");
  const saveBtn = document.getElementById("save-btn");
  const openBtn = document.getElementById("open-btn");
  const clearBtn = document.getElementById("clear-btn");

  // Save content to a file with a custom name
  saveBtn.addEventListener("click", () => {
    const fileName = prompt("Enter file name (with extension):", "newfile.txt");
    if (fileName) {
      const blob = new Blob([textEditor.value], { type: "text/plain" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = fileName;
      link.click();
    }
  });

  // Open a file and load its content
  openBtn.addEventListener("click", () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".txt,.md,.html,.js";
    input.addEventListener("change", (event) => {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          textEditor.value = e.target.result;
        };
        reader.readAsText(file);
      }
    });
    input.click();
  });

  // Clear the editor
  clearBtn.addEventListener("click", () => {
    textEditor.value = "";
  });
});


// Save on input
textEditor.addEventListener("input", () => {
  localStorage.setItem("textEditorContent", textEditor.value);
});

// Load on start
const saved = localStorage.getItem("textEditorContent");
if (saved) textEditor.value = saved;
